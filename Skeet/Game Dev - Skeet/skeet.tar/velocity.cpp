#include "velocity.h"


Velocity::Velocity(float dx, float dy)
{
   this->dx = dx;
   this->dy = dy;
}